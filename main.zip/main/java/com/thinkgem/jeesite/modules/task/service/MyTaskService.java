package com.thinkgem.jeesite.modules.task.service;

import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.thinkgem.jeesite.common.service.TreeService;
import com.thinkgem.jeesite.modules.sys.entity.User;
import com.thinkgem.jeesite.modules.sys.utils.UserUtils;
import com.thinkgem.jeesite.modules.task.dao.TaskDao;
import com.thinkgem.jeesite.modules.task.entity.Task;

@Service
@Transactional(readOnly = true)
public class MyTaskService extends TreeService<TaskDao, Task>{

	public List<Task> findByUser() {
		List<Task> list = Lists.newArrayList();
		
		User user = UserUtils.getUser();
		Task task = new Task();
		task.setParent(new Task());
		task.setCurrentUser(user);
		
		list = dao.findList(task);
		
		Set<String> parentIdSet = Sets.newHashSet();
		for (Task item : list) {
			if (item.getParent() != null && StringUtils.isNotBlank(item.getParent().getId())) {
				boolean isExistParent = false;
				for (Task item2 : list) {
					if (item.getParent().getId().equals(item2.getId())) {
						isExistParent = true;
						break;
					}
				}
				if (isExistParent) {
					
				}
			}
		}
		
		return list;
	}
}
