package com.thinkgem.jeesite.modules.task.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.google.common.collect.Lists;
import com.thinkgem.jeesite.common.web.BaseController;
import com.thinkgem.jeesite.modules.task.entity.Task;
import com.thinkgem.jeesite.modules.task.service.MyTaskService;

@Controller
@RequestMapping(value="${adminPath}/task")
public class TaskController extends BaseController{

	@Autowired
	private MyTaskService taskService;
	
	@RequestMapping(value="/tasklist")
	public String list(Model model) {
		List<Task> list = Lists.newArrayList();
		List<Task> sourceList = taskService.findByUser();
		Task.sortList(list, sourceList, "1");
		model.addAttribute("list", list);
		return "modules/task/taskList";
	}
}
