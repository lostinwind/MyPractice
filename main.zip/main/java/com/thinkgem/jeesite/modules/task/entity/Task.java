package com.thinkgem.jeesite.modules.task.entity;

import java.util.Date;
import java.util.List;

import com.thinkgem.jeesite.common.persistence.TreeEntity;
import com.thinkgem.jeesite.modules.sys.entity.User;

public class Task extends TreeEntity<Task>{
	
	private String level;
	private String state;
	private Date deadline;
	private String content;
	private List<User> userList;

	private static final long serialVersionUID = 1L;

	@Override
	public Task getParent() {
		return parent;
	}

	@Override
	public void setParent(Task parent) {
		this.parent = parent;
	}
	
	public Task(){
		super();
		this.sort = 30;
		this.delFlag = DEL_FLAG_NORMAL;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Date getDeadline() {
		return deadline;
	}

	public void setDeadline(Date deadline) {
		this.deadline = deadline;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public List<User> getUserList() {
		return userList;
	}

	public void setUserList(List<User> userList) {
		this.userList = userList;
	}

	public static void sortList(List<Task> list, List<Task> sourceList, String parentId) {
		for (int i = 0; i < sourceList.size(); i++) {
			Task task = sourceList.get(i);
			if (task.getParent() != null && task.getParent().getId() != null
					&& task.getParent().getId().equals(parentId)) {
				//默认1为根节点
				//1下面是一级
				list.add(task);
				//找二级
				sortList(list, sourceList, task.getId());
			}
		}
	}
}
